#include <lpc21xx.h>
#include "header.h"

// Global variable to store CAN message data
CAN2 data;
// Flag to indicate interrupt occurred
int flag = 0;
// Flag for Hall effect sensor (Reverse gear indicator) state
int flag_HL = 0;
// Flag for Left IR sensor state
int flag_LI = 0;
// Flag for Right IR sensor state
int flag_RI = 0;

// ADC channel for analog sensor readings from left ultrasonic sensor
#define ADC_CHANNEL_LEFT   0    // P0.28 - Left ultrasonic sensor
// ADC channel for center ultrasonic sensor
#define ADC_CHANNEL_CENTER 1    // P0.27 - Center ultrasonic sensor
// ADC channel for right ultrasonic sensor
#define ADC_CHANNEL_RIGHT  2    // P0.29 - Right ultrasonic sensor

// CAN message ID for left sensor data transmission
#define SENSOR_LEFT_ID     0x100
// CAN message ID for center sensor data transmission
#define SENSOR_CENTER_ID   0x101
// CAN message ID for right sensor data transmission
#define SENSOR_RIGHT_ID    0x102

// Maximum detectable distance in centimeters
#define MAX_DISTANCE       400   // Maximum distance in cm
// Minimum detectable distance in centimeters
#define MIN_DISTANCE       5     // Minimum distance in cm

// Function declaration to initialize entire system (GPIO, UART, ADC, CAN, Interrupts)
void init_system(void);
// Function declaration to initialize ADC peripheral
void init_adc(void);
// Function declaration to initialize GPIO pins
void init_gpio(void);
// Function declaration to read ADC value from specified channel
u16 read_adc(u8 channel);
// Function declaration to read distance from ultrasonic sensor
u16 read_ultrasonic(u8 channel);
// Function declaration to convert raw ADC value to distance in centimeters
u16 convert_adc_to_distance(u16 adc_value);
// Function declaration to send sensor data via CAN bus
void send_sensor_data(u8 sensor_id, u16 distance);
// Function declaration to display sensor readings on LCD and UART
void display_sensor_readings(u16 left, u16 center, u16 right);
// Function declaration to trigger ultrasonic sensor pulse (alternative method)
void trigger_sensor(u8 pin);
// Function declaration to measure echo pulse from ultrasonic sensor (alternative method)
u16 measure_echo(u8 pin);

// GPIO trigger pin for left ultrasonic sensor (Port 0, Pin 4)
#define TRIGGER_LEFT    (1 << 4)
// GPIO trigger pin for center ultrasonic sensor (Port 0, Pin 5)
#define TRIGGER_CENTER  (1 << 5)
// GPIO trigger pin for right ultrasonic sensor (Port 0, Pin 6)
#define TRIGGER_RIGHT   (1 << 6)

// GPIO echo pin for left ultrasonic sensor (Port 0, Pin 7)
#define ECHO_LEFT       (1 << 7)
// GPIO echo pin for center ultrasonic sensor (Port 0, Pin 8)
#define ECHO_CENTER     (1 << 8)
// GPIO echo pin for right ultrasonic sensor (Port 1, Pin 30)
#define ECHO_RIGHT      (1 << 30)

// Main function - entry point of program
int main(void)
{
    // Variable to store distance reading from left sensor in centimeters
    u16 distance_left = 0;
    // Variable to store distance reading from center sensor in centimeters
    u16 distance_center = 0;
    // Variable to store distance reading from right sensor in centimeters
    u16 distance_right = 0;
    // Static counter to track loop iterations for periodic updates
    static u32 loop_count = 0;
    
    // Call initialization function to setup all system peripherals
    init_system();
    
    // Send startup message to UART serial terminal
    uart0_tx_string("\r\n================================\r\n");
    // Print system identification
    uart0_tx_string("Reverse Parking Assistance System\r\n");
    // Identify this as Node A (Sensor Node)
    uart0_tx_string("LPC2129 - Node A (Sensor Node)\r\n");
    // Print separator line
    uart0_tx_string("================================\r\n");
    // Indicate system initialization in progress
    uart0_tx_string("Initializing sensors...\r\n");
    
    // Wait 500 milliseconds for system to stabilize
    delay_ms(500);
    
    // Initialize LCD display module
    lcd_init();
    // Send command to clear LCD display
    lcd_cmd(0x01);
    // Display startup message on LCD
    lcd_string("Node A Active");
    // Wait 1 second to show message
    delay_ms(1000);
    
    // Indicate system is ready and sensors are operational
    uart0_tx_string("System Ready - Reading Sensors\r\n");
    
    // Begin infinite main loop
    while(1)
    {
        //
